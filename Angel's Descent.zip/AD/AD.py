import pygame
import sys

pygame.init()

# Screen setup
WIDTH, HEIGHT = 1500, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Angel's Descent")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 50, 50)
GRAY = (100, 100, 100)
BLUE = (0, 0, 255)

# Font
font = pygame.font.SysFont(None, 35)

# Load images (make sure these files exist in same folder)
bg_start = pygame.image.load("forest.png")
bg_river = pygame.image.load("river.png")
bg_cave = pygame.image.load("cave.jpg")
bg_treasure = pygame.image.load("treasure.jpg")

# Resize images
bg_start = pygame.transform.scale(bg_start, (WIDTH, HEIGHT))
bg_river = pygame.transform.scale(bg_river, (WIDTH, HEIGHT))
bg_cave = pygame.transform.scale(bg_cave, (WIDTH, HEIGHT))
bg_treasure = pygame.transform.scale(bg_treasure, (WIDTH, HEIGHT))

# Game state
current_scene = "start"
health = 3
alpha = 0  # for fade animation

# Button class
class Button:
    def __init__(self, text, x, y, w, h):
        self.text = text
        self.rect = pygame.Rect(x, y, w, h)

    def draw(self):
        pygame.draw.rect(screen, GRAY, self.rect)
        label = font.render(self.text, True, WHITE)
        screen.blit(label, (self.rect.x + 10, self.rect.y + 10))

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

def draw_text(text, x, y):
    lines = text.split("\n")
    for i, line in enumerate(lines):
        img = font.render(line, True, WHITE)
        screen.blit(img, (x, y + i * 30))

def get_scene():
    global health

    if health <= 0:
        return "You have died..\nGame Over 💀", [], None

    if current_scene == "start":
        return ("You are in a forest.\nWhere do you go?",
                ["Go Left", "Go Right"], bg_start)

    elif current_scene == "river":
        return ("You reach a river.\nWhat do you do?",
                ["Swim (danger)", "Build raft"], bg_river)

    elif current_scene == "cave":
        return ("You enter a cave.\nWhat now?",
                ["Explore deeper", "Leave"], bg_cave)

    elif current_scene == "treasure":
        return ("You found treasure!\nOpen it?",
                ["Open", "Ignore"], bg_treasure)

    elif current_scene == "win":
        return "You found gold! You win! 🏆", [], bg_treasure

    return "", [], None

def handle_choice(choice):
    global current_scene, health, alpha

    alpha = 0  # reset animation

    if current_scene == "start":
        current_scene = "river" if choice == 0 else "cave"

    elif current_scene == "river":
        if choice == 0:
            health -= 1
            current_scene = "start"
        else:
            current_scene = "treasure"

    elif current_scene == "cave":
        if choice == 0:
            health -= 1
            current_scene = "start"
        else:
            current_scene = "start"

    elif current_scene == "treasure":
        if choice == 0:
            current_scene = "win"
        else:
            health -= 1
            current_scene = "start"

# Game loop
clock = pygame.time.Clock()
running = True

while running:
    screen.fill(BLACK)

    text, choices, bg = get_scene()

    # Draw background
    if bg:
        screen.blit(bg, (0, 0))

    # Fade animation
    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(255 - alpha)
    overlay.fill(BLACK)
    screen.blit(overlay, (0, 0))

    if alpha < 255:
        alpha += 5

    # Draw text
    draw_text(text, 50, 50)

    # Draw health
    health_text = font.render(f"Health: {health}", True, BLUE)
    screen.blit(health_text, (650, 20))

    # Create buttons
    buttons = []
    for i, choice in enumerate(choices):
        btn = Button(choice, 50, 300 + i * 60, 200, 50)
        btn.draw()
        buttons.append(btn)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            for i, btn in enumerate(buttons):
                if btn.is_clicked(event.pos):
                    handle_choice(i)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()