import pygame
import sys
import random

pygame.init()

# Screen
WIDTH, HEIGHT = 1500, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Angel's Descent")

# Colors & Font
WHITE = (245, 245, 245)
BLACK = (20, 20, 20)
RED = (200, 50, 50)
BOX_COLOR = (0, 0, 0, 180)  # semi-transparent
font = pygame.font.SysFont(None, 35)

# Load images
bg_start = pygame.transform.scale(pygame.image.load("door.jpg"), (WIDTH, HEIGHT))
bg_hall = pygame.transform.scale(pygame.image.load("hall.jpg"), (WIDTH, HEIGHT))
bg_room = pygame.transform.scale(pygame.image.load("room.jpg"), (WIDTH, HEIGHT))
heart = pygame.transform.scale(pygame.image.load("heart_full.png"), (40, 40))

# Game state
scene = "start"
health = 3

# Typing effect
display_text = ""
char_index = 0
typing_speed = 2
frame = 0

# Input system
user_input = ""
input_active = False

# Timer
time_limit = 10
start_time = 0

# Questions
questions = [
    ("What is 2 + 2?", "4"),
    ("What is 5 x 3?", "15"),
    ("What is 10 - 6?", "4"),
    ("What is 9 / 3?", "3"),
    ("What is 7 + 8?", "15")
]

current_question = ""
correct_answer = ""

def get_random_question():
    return random.choice(questions)

# Scenes
scenes = {
    "start": ("You see a door. Will you go in?", bg_start, [
        ("Go straight", "hall", 0),
        ("Go right", "room", 0)
    ]),
    "hall": ("You reach an empty hall. What do you do?", bg_hall, [
        ("Shout for help", "start", 1),
        ("Investigate", "riddle", 0)
    ]),
    "room": ("You entered a creepy room. What now?", bg_room, [
        ("Explore deeper", "riddle", 0),
        ("Leave", "hall", 0)
    ]),
    "correct": ("Correct! You may proceed.", bg_start, [
        ("Continue", "treasure", 0)
    ]),
    "wrong": ("Wrong or too slow! Try again.", bg_room, [
        ("Retry", "riddle", 0)
    ]),
    "treasure": ("You found a treasure chest. Open it?", bg_start, [
        ("Open", "win", 0),
        ("Ignore", "hall", 0)
    ]),
    "win": ("You found gold! You win! 🏆", bg_start, [])
}

# Button
class Button:
    def __init__(self, text, rect):
        self.text = text
        self.rect = rect

    def draw(self):
        pygame.draw.rect(screen, (220, 70, 70), self.rect, border_radius=10)
        pygame.draw.rect(screen, WHITE, self.rect, 2, border_radius=10)

        label = font.render(self.text, True, WHITE)
        screen.blit(label, label.get_rect(center=self.rect.center))

    def clicked(self, pos):
        return self.rect.collidepoint(pos)


def draw_hearts():
    for i in range(health):
        screen.blit(heart, (1300 + i * 45, 20))


# Dialogue box at bottom
def draw_dialogue_box(text):
    box_height = 200
    box_surface = pygame.Surface((WIDTH, box_height), pygame.SRCALPHA)
    box_surface.fill(BOX_COLOR)

    screen.blit(box_surface, (0, HEIGHT - box_height))

    y = HEIGHT - box_height + 30
    for line in wrap_text(text, WIDTH - 100):
        img = font.render(line, True, WHITE)
        screen.blit(img, (50, y))
        y += 40


# Wrap long text
def wrap_text(text, max_width):
    words = text.split(" ")
    lines = []
    current_line = ""

    for word in words:
        test_line = current_line + word + " "
        if font.size(test_line)[0] < max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word + " "

    lines.append(current_line)
    return lines


def draw_timer(time_left):
    timer_text = font.render(f"Time: {time_left}", True, RED)
    screen.blit(timer_text, (50, 20))


# Main loop
clock = pygame.time.Clock()
running = True

while running:
    screen.fill(BLACK)

    # Scene logic
    if health <= 0:
        text, bg, choices = "You died... Click Restart.", None, [("Restart", "start", 0)]
    else:
        if scene == "riddle":
            if current_question == "":
                q, a = get_random_question()
                current_question = q
                correct_answer = a
                start_time = pygame.time.get_ticks()

            text = current_question
            bg = bg_room
            choices = []
        else:
            text, bg, choices = scenes[scene]
            current_question = ""

    input_active = (scene == "riddle")

    # Background
    if bg:
        screen.blit(bg, (0, 0))

    # Typing effect
    frame += 1
    if char_index < len(text) and frame % typing_speed == 0:
        display_text += text[char_index]
        char_index += 1

    # Draw UI
    draw_dialogue_box(display_text)
    draw_hearts()

    # Timer
    if input_active:
        elapsed = (pygame.time.get_ticks() - start_time) // 1000
        time_left = max(0, time_limit - elapsed)
        draw_timer(time_left)

        if time_left == 0:
            health -= 1
            scene = "wrong"
            display_text = ""
            char_index = 0
            user_input = ""
            current_question = ""

    # Input box
    if input_active:
        input_box = pygame.Rect(550, HEIGHT - 120, 400, 40)
        pygame.draw.rect(screen, WHITE, input_box, 2)

        input_surface = font.render(user_input, True, WHITE)
        screen.blit(input_surface, (input_box.x + 10, input_box.y + 5))

    # Buttons
    buttons = []
    if choices:
        start_x = (WIDTH - (len(choices) * 250)) // 2

        for i, (label, nxt, dmg) in enumerate(choices):
            rect = pygame.Rect(start_x + i * 300, HEIGHT - 250, 200, 50)
            btn = Button(label, rect)
            btn.draw()
            buttons.append((btn, nxt, dmg))

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN and input_active:
            if event.key == pygame.K_RETURN:
                if user_input.strip() == correct_answer:
                    scene = "correct"
                else:
                    health -= 1
                    scene = "wrong"

                display_text = ""
                char_index = 0
                user_input = ""
                current_question = ""

            elif event.key == pygame.K_BACKSPACE:
                user_input = user_input[:-1]
            else:
                user_input += event.unicode

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if char_index < len(text):
                display_text = text
                char_index = len(text)
                continue

            for btn, nxt, dmg in buttons:
                if btn.clicked(event.pos):
                    if health <= 0:
                        health = 3
                        scene = "start"
                    else:
                        health -= dmg
                        scene = nxt

                    display_text = ""
                    char_index = 0
                    break

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()