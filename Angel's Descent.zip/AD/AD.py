import pygame
import sys

pygame.init()

# Screen
WIDTH, HEIGHT = 1500, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Angel's Descent")

# Colors & Font
WHITE = (245, 245, 245)
BLACK = (20, 20, 20)
font = pygame.font.SysFont(None, 35)

# Load images
bg_start = pygame.transform.scale(pygame.image.load("door.jpg"), (WIDTH, HEIGHT))
bg_hall = pygame.transform.scale(pygame.image.load("hall.jpg"), (WIDTH, HEIGHT))
bg_room = pygame.transform.scale(pygame.image.load("room.jpg"), (WIDTH, HEIGHT))
heart = pygame.transform.scale(pygame.image.load("heart_full.png"), (40, 40))

# Game state
scene = "start"
health = 3

# Typing effect
display_text = ""
char_index = 0
typing_speed = 2
frame = 0

# Scenes
scenes = {
    "start": ("You see a door. Will you go in?", bg_start, [
        ("Go straight", "hall", 0),
        ("Go right", "room", 0)
    ]),
    "hall": ("You reach an empty hall. What do you do?", bg_hall, [
        ("Shout for help", "start", 1),
        ("Investigate", "treasure", 0)
    ]),
    "room": ("You entered a creepy room. What now?", bg_room, [
        ("Explore deeper", "treasure", 0),
        ("Leave", "hall", 0)
    ]),
    "treasure": ("You found a treasure chest. Open it?", bg_start, [
        ("Open", "win", 0),
        ("Ignore", "hall", 0)
    ]),
    "win": ("You found gold! You win! 🏆", bg_start, [])
}

# Button
class Button:
    def __init__(self, text, rect):
        self.text = text
        self.rect = rect

    def draw(self):
        pygame.draw.rect(screen, (220, 70, 70), self.rect, border_radius=10)
        pygame.draw.rect(screen, WHITE, self.rect, 2, border_radius=10)

        label = font.render(self.text, True, WHITE)
        screen.blit(label, label.get_rect(center=self.rect.center))

    def clicked(self, pos):
        return self.rect.collidepoint(pos)


def draw_hearts():
    for i in range(health):
        screen.blit(heart, (1300 + i * 45, 20))


def draw_text(text):
    y = 100
    for line in text.split("\n"):
        img = font.render(line, True, WHITE)
        screen.blit(img, (500, y))
        y += 50


# Main loop
clock = pygame.time.Clock()
running = True

while running:
    screen.fill(BLACK)

    # Get scene data
    if health <= 0:
        text, bg, choices = "You died... Click Restart.", None, [("Restart", "start", 0)]
    else:
        text, bg, choices = scenes[scene]

    # Background
    if bg:
        screen.blit(bg, (0, 0))

    # Typing effect
    frame += 1
    if char_index < len(text) and frame % typing_speed == 0:
        display_text += text[char_index]
        char_index += 1

    draw_text(display_text)
    draw_hearts()

    # Buttons
    buttons = []
    if choices:
        start_x = (WIDTH - (len(choices) * 250)) // 2

        for i, (label, nxt, dmg) in enumerate(choices):
            rect = pygame.Rect(start_x + i * 300, 600, 200, 50)
            btn = Button(label, rect)
            btn.draw()
            buttons.append((btn, nxt, dmg))

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # Skip typing
            if char_index < len(text):
                display_text = text
                char_index = len(text)
                continue

            # Handle clicks
            for btn, nxt, dmg in buttons:
                if btn.clicked(event.pos):
                    if health <= 0:  # restart condition
                        health = 3
                        scene = "start"
                    else:
                        health -= dmg
                        scene = nxt

                    display_text = ""
                    char_index = 0
                    break

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()